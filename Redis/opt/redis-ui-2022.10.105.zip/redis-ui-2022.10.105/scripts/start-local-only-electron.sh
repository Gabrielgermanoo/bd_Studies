#!/usr/bin/env bash
#DEBUG=serialport:*,ngivr-arabesque:*
#REM yarn link ngivr-ms-arabesque
NODE_ENV=test ./node_modules/.bin/electron .
